INSERT INTO missions
	(agent, title, gadget1, gadget2)
VALUES
	('Johnny English', 'Rescue the Queen',
	'Exploding Cigar', 'Voice Controlled Rolls Royce'),
	
	('Natasha Romanova', 'Kill Iron Man',
	'Armored Suit', 'Indestructible Pole');