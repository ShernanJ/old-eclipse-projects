CREATE TABLE missions (
	id LONG PRIMARY KEY AUTO_INCREMENT,
	agent VARCHAR(50),
	title VARCHAR(50),
	gadget1 VARCHAR(50),
	gadget2 VARCHAR(50)
);